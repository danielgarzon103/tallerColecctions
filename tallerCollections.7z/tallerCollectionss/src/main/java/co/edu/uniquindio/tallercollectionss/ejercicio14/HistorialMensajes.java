package co.edu.uniquindio.tallercollectionss.ejercicio14;
import java.util.ArrayDeque;
import java.util.Deque;

public class HistorialMensajes {
    private static final int LIMITE_HISTORIAL = 10;
    private Deque<String> mensajes;

    public HistorialMensajes() {
        this.mensajes = new ArrayDeque<>();
    }

    public void agregarMensaje(String mensaje) {
        if (mensajes.size() >= LIMITE_HISTORIAL) {
            mensajes.pollFirst();
        }
        mensajes.addLast(mensaje);
        System.out.println(" Mensaje agregado: " + mensaje);
    }

    public void mostrarHistorial() {
        if (mensajes.isEmpty()) {
            System.out.println(" No hay mensajes en el historial.");
        } else {
            System.out.println("\n Últimos mensajes enviados:");
            for (String mensaje : mensajes) {
                System.out.println("💬 " + mensaje);
            }
        }
    }

    public static void main(String[] args) {
        HistorialMensajes chat = new HistorialMensajes();

        for (int i = 1; i <= 12; i++) {
            chat.agregarMensaje("Mensaje " + i);
        }

        chat.mostrarHistorial();
    }
}
