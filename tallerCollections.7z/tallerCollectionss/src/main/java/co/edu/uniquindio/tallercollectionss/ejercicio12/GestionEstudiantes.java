package co.edu.uniquindio.tallercollectionss.ejercicio12;

import java.util.Scanner;
import java.util.TreeSet;

public class GestionEstudiantes {
    private TreeSet<String> estudiantes = new TreeSet<>();

    public void agregarEstudiante(String nombre) {
        if (estudiantes.add(nombre)) {
            System.out.println(nombre + "' agregado correctamente.\n");
        } else {
            System.out.println(nombre + "' ya está en la lista.\n");
        }
    }

    public void eliminarEstudiante(String nombre) {
        if (estudiantes.remove(nombre)) {
            System.out.println(nombre + "' eliminado correctamente.\n");
        } else {
            System.out.println(nombre + "' no se encontró en la lista.\n");
        }
    }

    public void listarEstudiantes() {
        if (estudiantes.isEmpty()) {
            System.out.println("No hay estudiantes en la lista.\n");
        } else {
            System.out.println("\nLista de estudiantes:");
            for (String nombre : estudiantes) {
                System.out.println(nombre);
            }
            System.out.println();
        }
    }

    public void mostrarPrimerYUltimo() {
        if (!estudiantes.isEmpty()) {
            System.out.println("\nPrimer estudiante: " + estudiantes.first());
            System.out.println("Último estudiante: " + estudiantes.last() + "\n");
        } else {
            System.out.println("⚠️ No hay estudiantes registrados.\n");
        }
    }

    public void menu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("===  GESTOR DE ESTUDIANTES ===");
            System.out.println("1. Agregar estudiante");
            System.out.println("2. Eliminar estudiante");
            System.out.println("3. Listar estudiantes");
            System.out.println("4. Mostrar primer y último estudiante");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.print("Ingrese el nombre del estudiante: ");
                    String nombre = scanner.nextLine();
                    agregarEstudiante(nombre);
                }
                case 2 -> {
                    System.out.print("Ingrese el nombre del estudiante a eliminar: ");
                    String nombre = scanner.nextLine();
                    eliminarEstudiante(nombre);
                }
                case 3 -> listarEstudiantes();
                case 4 -> mostrarPrimerYUltimo();
                case 5 -> System.out.println(" Saliendo del gestor de estudiantes...");
                default -> System.out.println(" Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 5);
    }

    public static void main(String[] args) {
        GestionEstudiantes gestor = new GestionEstudiantes();
        gestor.menu();
    }
}
