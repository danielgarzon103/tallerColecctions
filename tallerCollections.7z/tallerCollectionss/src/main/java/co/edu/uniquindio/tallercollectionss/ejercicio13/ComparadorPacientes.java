package co.edu.uniquindio.tallercollectionss.ejercicio13;

import java.util.Comparator;

public class ComparadorPacientes implements Comparator<Paciente> {
    @Override
    public int compare(Paciente p1, Paciente p2) {
        return Integer.compare(p2.getGravedad(), p1.getGravedad()); // Orden descendente
    }
}