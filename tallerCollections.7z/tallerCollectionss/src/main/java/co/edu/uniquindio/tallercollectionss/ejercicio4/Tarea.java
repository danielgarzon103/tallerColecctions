package co.edu.uniquindio.tallercollectionss.ejercicio4;

class Tarea implements Comparable<Tarea> {
    private String nombre;
    private int importancia;
    public Tarea(String nombre, int importancia) {
        this.nombre = nombre;
        this.importancia = importancia;
    }

    public String getNombre() {
        return nombre;
    }

    public int getImportancia() {
        return importancia;
    }

    @Override
    public int compareTo(Tarea otra) {
        return Integer.compare(this.importancia, otra.importancia);
    }

    @Override
    public String toString() {
        return "Tarea: " + nombre + " (Prioridad: " + importancia + ")";
    }
}