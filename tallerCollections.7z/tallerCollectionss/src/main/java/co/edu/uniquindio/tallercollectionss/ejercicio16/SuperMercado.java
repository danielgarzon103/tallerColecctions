package co.edu.uniquindio.tallercollectionss.ejercicio16;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class SuperMercado {
    private LinkedHashMap<String, Double> carrito;

    public SuperMercado() {
        this.carrito = new LinkedHashMap<>();
    }

    // Agregar un producto al carrito
    public void agregarProducto(String producto, double precio) {
        carrito.put(producto, precio);
        System.out.println(" Producto agregado: " + producto + " - $" + precio);
    }

    // Mostrar el listado de productos en el orden en que fueron añadidos
    public void mostrarCarrito() {
        if (carrito.isEmpty()) {
            System.out.println(" El carrito está vacío.");
        } else {
            System.out.println("\n Lista de productos:");
            for (Map.Entry<String, Double> entry : carrito.entrySet()) {
                System.out.println(" " + entry.getKey() + " - $" + entry.getValue());
            }
        }
    }

    public void calcularTotal() {
        double total = 0;
        for (double precio : carrito.values()) {
            total += precio;
        }
        System.out.println("\n Total de la compra: $" + total);
    }

    public static void main(String[] args) {
        SuperMercado supermercado = new SuperMercado();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n Menú del Supermercado:");
            System.out.println(" Agregar producto");
            System.out.println(" Mostrar carrito");
            System.out.println(" Calcular total");
            System.out.println(" Finalizar compra");
            System.out.print(" Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("🛍 Nombre del producto: ");
                    String producto = scanner.nextLine();
                    System.out.print(" Precio: ");
                    double precio = scanner.nextDouble();
                    supermercado.agregarProducto(producto, precio);
                    break;
                case 2:
                    supermercado.mostrarCarrito();
                    break;
                case 3:
                    supermercado.calcularTotal();
                    break;
                case 0:
                    System.out.println("🛒 Compra finalizada. ¡Gracias por su compra!");
                    break;
                default:
                    System.out.println("⚠️ Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}