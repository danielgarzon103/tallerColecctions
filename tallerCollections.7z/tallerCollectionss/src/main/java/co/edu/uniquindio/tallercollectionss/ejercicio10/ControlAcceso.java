package co.edu.uniquindio.tallercollectionss.ejercicio10;
import java.util.HashSet;
import java.util.Scanner;

public class ControlAcceso {
    private HashSet<String> empleados = new HashSet<>();
    private Scanner scanner = new Scanner(System.in);

    public void registrarEmpleado() {
        System.out.print("Ingrese el ID del empleado: ");
        String id = scanner.nextLine();

        if (empleados.add(id)) {
            System.out.println("Empleado registrado correctamente.\n");
        } else {
            System.out.println("Error: Este ID ya está registrado.\n");
        }
    }

    public void verificarAcceso() {
        System.out.print("Ingrese el ID del empleado para acceso: ");
        String id = scanner.nextLine();

        if (empleados.contains(id)) {
            System.out.println("Acceso permitido. Bienvenido.\n");
        } else {
            System.out.println("Acceso denegado. ID no registrado.\n");
        }
    }

    public void mostrarEmpleados() {
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados registrados.\n");
        } else {
            System.out.println("\nEmpleados Registrados:");
            for (String id : empleados) {
                System.out.println("- " + id);
            }
            System.out.println();
        }
    }

    public void eliminarEmpleado() {
        System.out.print("Ingrese el ID del empleado a eliminar: ");
        String id = scanner.nextLine();

        if (empleados.remove(id)) {
            System.out.println("Empleado eliminado correctamente.\n");
        } else {
            System.out.println("Error: ID no encontrado.\n");
        }
    }

    public void menu() {
        int opcion;
        do {
            System.out.println("=== CONTROL DE ACCESO ===");
            System.out.println("1. Registrar empleado");
            System.out.println("2. Verificar acceso");
            System.out.println("3. Mostrar empleados registrados");
            System.out.println("4. Eliminar empleado");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> registrarEmpleado();
                case 2 -> verificarAcceso();
                case 3 -> mostrarEmpleados();
                case 4 -> eliminarEmpleado();
                case 5 -> System.out.println("Saliendo del sistema de control de acceso...");
                default -> System.out.println("Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 5);
    }

    public static void main(String[] args) {
        ControlAcceso sistema = new ControlAcceso();
        sistema.menu();
    }
}
