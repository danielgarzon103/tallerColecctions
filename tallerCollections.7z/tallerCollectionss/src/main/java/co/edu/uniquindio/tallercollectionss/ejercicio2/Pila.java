package co.edu.uniquindio.tallercollectionss.ejercicio2;

import java.util.Stack;

public class Pila {
    public static void main(String[] args) {
        Stack<Object> pila= new Stack<>();
        String carro= "mazda";
        int edad= 19;
        int edad2= 20;
        insetarObjeto(pila, edad2);
        insetarObjeto(pila,carro);
    }

    private static void insetarObjeto(Stack<Object> pila, Object i) {
        if (pila.isEmpty()){
            pila.push(i);
        } else if (pila.peek().getClass().equals(i.getClass())) {
            pila.push(i);
        }
        System.out.println(pila);
    }
}
