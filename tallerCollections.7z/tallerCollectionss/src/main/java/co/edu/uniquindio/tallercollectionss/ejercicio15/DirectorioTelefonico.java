package co.edu.uniquindio.tallercollectionss.ejercicio15;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class DirectorioTelefonico {
    private Map<String, String> contactos;

    public DirectorioTelefonico() {
        this.contactos = new HashMap<>();
    }

    public void agregarContacto(String nombre, String telefono) {
        contactos.put(nombre, telefono);
        System.out.println(" Contacto agregado: " + nombre + " -> " + telefono);
    }

    public void buscarContacto(String nombre) {
        if (contactos.containsKey(nombre)) {
            System.out.println(" " + nombre + " -> " + contactos.get(nombre));
        } else {
            System.out.println(" Contacto no encontrado.");
        }
    }

    public void eliminarContacto(String nombre) {
        if (contactos.remove(nombre) != null) {
            System.out.println("🗑 Contacto eliminado: " + nombre);
        } else {
            System.out.println(" No se encontró el contacto.");
        }
    }

    public void mostrarContactos() {
        if (contactos.isEmpty()) {
            System.out.println(" No hay contactos guardados.");
        } else {
            System.out.println("\n Lista de contactos:");
            for (Map.Entry<String, String> entrada : contactos.entrySet()) {
                System.out.println(" " + entrada.getKey() + " -> " + entrada.getValue());
            }
        }
    }

    public static void main(String[] args) {
        DirectorioTelefonico directorio = new DirectorioTelefonico();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n Menú del Directorio Telefónico:");
            System.out.println(" Agregar contacto");
            System.out.println(" Buscar contacto");
            System.out.println(" Eliminar contacto");
            System.out.println(" Mostrar todos los contactos");
            System.out.println(" Salir");
            System.out.print(" Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print(" Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print(" Teléfono: ");
                    String telefono = scanner.nextLine();
                    directorio.agregarContacto(nombre, telefono);
                    break;
                case 2:
                    System.out.print(" Nombre a buscar: ");
                    String buscar = scanner.nextLine();
                    directorio.buscarContacto(buscar);
                    break;
                case 3:
                    System.out.print(" Nombre a eliminar: ");
                    String eliminar = scanner.nextLine();
                    directorio.eliminarContacto(eliminar);
                    break;
                case 4:
                    directorio.mostrarContactos();
                    break;
                case 0:
                    System.out.println(" Saliendo del directorio...");
                    break;
                default:
                    System.out.println(" Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}