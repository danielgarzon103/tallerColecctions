package co.edu.uniquindio.tallercollectionss.ejercicio5;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        // HashMap: No garantiza orden de los elementos, es probable que salgan en un orden aleatorio si son muchas claves
        Map<Integer, String> hashMap = new HashMap<>();
        hashMap.put(3, "Monitor");
        hashMap.put(1, "Teclado");
        hashMap.put(4, "Mouse");
        hashMap.put(2, "CPU");

        // LinkedHashMap: Mantiene el orden de inserción
        Map<Integer, String> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put(3, "Monitor");
        linkedHashMap.put(1, "Teclado");
        linkedHashMap.put(4, "Mouse");
        linkedHashMap.put(2, "CPU");

        // TreeMap: Ordena automáticamente por clave
        Map<Integer, String> treeMap = new TreeMap<>();
        treeMap.put(3, "Monitor");
        treeMap.put(1, "Teclado");
        treeMap.put(4, "Mouse");
        treeMap.put(2, "CPU");


        System.out.println("HashMap (orden aleatorio): " + hashMap);
        System.out.println("LinkedHashMap (orden de inserción): " + linkedHashMap);
        System.out.println("TreeMap (ordenado por clave): " + treeMap);
    }
}