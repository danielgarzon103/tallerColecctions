package co.edu.uniquindio.tallercollectionss.ejercicio7;

import java.util.LinkedList;
import java.util.Scanner;

public class BancoAtencion {
    private LinkedList<String> colaClientes = new LinkedList<>();
    private Scanner scanner = new Scanner(System.in);

    public void agregarCliente() {
        System.out.print("Ingrese el nombre del cliente: ");
        String nombre = scanner.nextLine();
        colaClientes.addLast(nombre);
        System.out.println("Cliente agregado a la cola.\n");
    }

    public void atenderCliente() {
        if (colaClientes.isEmpty()) {
            System.out.println("No hay clientes en la cola.\n");
        } else {
            String atendido = colaClientes.removeFirst();
            System.out.println("Atendiendo a: " + atendido + "\n");
        }
    }

    public void agregarClienteUrgente() {
        System.out.print("Ingrese el nombre del cliente urgente: ");
        String nombre = scanner.nextLine();
        colaClientes.addFirst(nombre);
        System.out.println("Cliente agregado con urgencia al inicio de la cola.\n");
    }

    public void mostrarCola() {
        if (colaClientes.isEmpty()) {
            System.out.println("No hay clientes en espera.\n");
        } else {
            System.out.println("\nClientes en espera:");
            for (String cliente : colaClientes) {
                System.out.println("- " + cliente);
            }
            System.out.println();
        }
    }

    public void menu() {
        int opcion;
        do {
            System.out.println("=== SISTEMA DE ATENCIÓN AL CLIENTE ===");
            System.out.println("1. Agregar cliente a la cola");
            System.out.println("2. Atender cliente");
            System.out.println("3. Agregar cliente urgente");
            System.out.println("4. Mostrar lista de espera");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> agregarCliente();
                case 2 -> atenderCliente();
                case 3 -> agregarClienteUrgente();
                case 4 -> mostrarCola();
                case 5 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 5);
    }

    public static void main(String[] args) {
        BancoAtencion banco = new BancoAtencion();
        banco.menu();
    }
}