package co.edu.uniquindio.tallercollectionss.ejercicio3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Set<String> elementos = new HashSet<>();

        elementos.add("Manzana");
        elementos.add("Banana");
        elementos.add("Naranja");
        elementos.add("Uva");
        elementos.add("Banana");

        Iterator<String> iterador = elementos.iterator();

        System.out.println("Elementos de la lista:");
        while (iterador.hasNext()) {
            System.out.println(iterador.next());
        }
    }
}
