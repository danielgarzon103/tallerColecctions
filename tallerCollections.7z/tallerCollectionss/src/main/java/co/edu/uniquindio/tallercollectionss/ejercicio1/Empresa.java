package co.edu.uniquindio.tallercollectionss.ejercicio1;

import java.util.TreeSet;

public class Empresa {
    public static void main(String[] args) {
        TreeSet<Producto> listaProductos= new TreeSet<>();
        listaProductos.add(new Producto(0003,"Impresora"));
        listaProductos.add(new Producto(0002,"Celular"));
        listaProductos.add(new Producto(0001,"Impresora"));

        System.out.println(buscarProducto(listaProductos,002));
    }

    private static String buscarProducto(TreeSet<Producto> listaProductos, int codigo) {
        System.out.println(listaProductos);
        for (Producto producto: listaProductos){
            if (producto.getCodigo()== codigo){
                return producto.getNombre();
            }
        }return "No se encontró el producto";
    }
}
