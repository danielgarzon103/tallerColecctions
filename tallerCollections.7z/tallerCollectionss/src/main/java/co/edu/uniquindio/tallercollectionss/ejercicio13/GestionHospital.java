package co.edu.uniquindio.tallercollectionss.ejercicio13;

import java.util.PriorityQueue;

public class GestionHospital {
    private PriorityQueue<Paciente> colaPacientes;

    public GestionHospital() {
        this.colaPacientes = new PriorityQueue<>(new ComparadorPacientes());
    }

    public void agregarPaciente(String nombre, int gravedad) {
        Paciente paciente = new Paciente(nombre, gravedad);
        colaPacientes.add(paciente);
        System.out.println(" Paciente agregado: " + paciente);
    }

    public void atenderPaciente() {
        if (!colaPacientes.isEmpty()) {
            Paciente atendido = colaPacientes.poll();
            System.out.println(" Atendiendo a: " + atendido);
        } else {
            System.out.println(" No hay pacientes en espera.");
        }
    }

    public void listarPacientes() {
        if (colaPacientes.isEmpty()) {
            System.out.println(" No hay pacientes en espera.");
        } else {
            System.out.println("\n Lista de pacientes en espera:");
            for (Paciente p : colaPacientes) {
                System.out.println(p);
            }
        }
    }

    public static void main(String[] args) {
        GestionHospital hospital = new GestionHospital();

        hospital.agregarPaciente("Juan", 3);
        hospital.agregarPaciente("Maria", 5);
        hospital.agregarPaciente("Carlos", 2);
        hospital.agregarPaciente("Ana", 4);

        hospital.listarPacientes();

        hospital.atenderPaciente();
        hospital.atenderPaciente();

        hospital.listarPacientes();
    }
}
