package co.edu.uniquindio.tallercollectionss.ejercicio9;

import java.util.Scanner;
import java.util.Stack;

public class NavegacionWeb {
    private Stack<String> historial = new Stack<>();
    private Scanner scanner = new Scanner(System.in);

    // Visitar una nueva página (se añade a la pila)
    public void visitarPagina() {
        System.out.print("Ingrese la URL de la página: ");
        String url = scanner.nextLine();
        historial.push(url);
        System.out.println("Página visitada: " + url + "\n");
    }

    // Retroceder a la página anterior (se elimina la última visitada)
    public void retroceder() {
        if (historial.size() <= 1) {
            System.out.println("No hay páginas anteriores a las que volver.\n");
        } else {
            historial.pop();
            System.out.println("Retrocediendo... Página actual: " + historial.peek() + "\n");
        }
    }

    // Mostrar la página actual
    public void mostrarPaginaActual() {
        if (historial.isEmpty()) {
            System.out.println("No hay páginas visitadas aún.\n");
        } else {
            System.out.println("Página actual: " + historial.peek() + "\n");
        }
    }

    // Mostrar historial de navegación
    public void mostrarHistorial() {
        if (historial.isEmpty()) {
            System.out.println("El historial está vacío.\n");
        } else {
            System.out.println("\nHistorial de navegación:");
            for (int i = historial.size() - 1; i >= 0; i--) {
                System.out.println((historial.size() - i) + ". " + historial.get(i));
            }
            System.out.println();
        }
    }

    // Menú interactivo
    public void menu() {
        int opcion;
        do {
            System.out.println("=== NAVEGACIÓN WEB ===");
            System.out.println("1. Visitar nueva página");
            System.out.println("2. Retroceder");
            System.out.println("3. Mostrar página actual");
            System.out.println("4. Mostrar historial");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1 -> visitarPagina();
                case 2 -> retroceder();
                case 3 -> mostrarPaginaActual();
                case 4 -> mostrarHistorial();
                case 5 -> System.out.println("Saliendo del navegador...");
                default -> System.out.println("Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 5);
    }

    public static void main(String[] args) {
        NavegacionWeb navegador = new NavegacionWeb();
        navegador.menu();
    }
}
