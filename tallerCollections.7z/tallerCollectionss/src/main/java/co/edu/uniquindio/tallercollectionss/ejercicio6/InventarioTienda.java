package co.edu.uniquindio.tallercollectionss.ejercicio6;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class InventarioTienda {
    private ArrayList<Producto> inventario = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void agregarProducto() {
        System.out.print("Ingrese el código del producto: ");
        String codigo = scanner.nextLine();
        System.out.print("Ingrese el nombre del producto: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el precio del producto: ");
        double precio = scanner.nextDouble();
        scanner.nextLine();

        inventario.add(new Producto(codigo, nombre, precio));
        System.out.println("Producto agregado exitosamente.\n");
    }

    public void eliminarProducto() {
        System.out.print("Ingrese el código del producto a eliminar: ");
        String codigo = scanner.nextLine();

        inventario.removeIf(p -> p.getCodigo().equalsIgnoreCase(codigo));
        System.out.println("Producto eliminado (si existía).\n");
    }

    public void buscarProducto() {
        System.out.print("Ingrese el nombre o código del producto: ");
        String criterio = scanner.nextLine();

        for (Producto p : inventario) {
            if (p.getCodigo().equalsIgnoreCase(criterio) || p.getNombre().equalsIgnoreCase(criterio)) {
                System.out.println("Producto encontrado: " + p);
                return;
            }
        }
        System.out.println("Producto no encontrado.\n");
    }

    public void listarProductosPorNombre() {
        ArrayList<Producto> copia = new ArrayList<>(inventario);
        copia.sort(Comparator.comparing(Producto::getNombre));

        System.out.println("\nInventario ordenado por nombre:");
        copia.forEach(System.out::println);
        System.out.println();
    }

    public void listarProductosPorPrecio() {
        ArrayList<Producto> copia = new ArrayList<>(inventario);
        copia.sort(Comparator.comparingDouble(Producto::getPrecio));

        System.out.println("\nInventario ordenado por precio:");
        copia.forEach(System.out::println);
        System.out.println();
    }

    public void menu() {
        int opcion;
        do {
            System.out.println("=== GESTIÓN DE INVENTARIO ===");
            System.out.println("1. Agregar producto");
            System.out.println("2. Eliminar producto");
            System.out.println("3. Buscar producto");
            System.out.println("4. Listar productos por nombre");
            System.out.println("5. Listar productos por precio");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> agregarProducto();
                case 2 -> eliminarProducto();
                case 3 -> buscarProducto();
                case 4 -> listarProductosPorNombre();
                case 5 -> listarProductosPorPrecio();
                case 6 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 6);
    }

    public static void main(String[] args) {
        InventarioTienda tienda = new InventarioTienda();
        tienda.menu();
    }
}