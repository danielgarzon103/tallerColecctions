package co.edu.uniquindio.tallercollectionss.ejercicio11;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class FavoritosMusicales {
    private LinkedHashSet<String> cancionesFavoritas = new LinkedHashSet<>();

    public void agregarCancion(String cancion) {
        if (cancionesFavoritas.add(cancion)) {
            System.out.println(cancion + "' añadida a favoritos.\n");
        } else {
            System.out.println("️ La canción '" + cancion + "' ya está en favoritos.\n");
        }
    }

    public void eliminarCancion(String cancion) {
        if (cancionesFavoritas.remove(cancion)) {
            System.out.println(" '" + cancion + "' eliminada de favoritos.\n");
        } else {
            System.out.println(" La canción '" + cancion + "' no está en favoritos.\n");
        }
    }
    public void listarFavoritos() {
        if (cancionesFavoritas.isEmpty()) {
            System.out.println(" No tienes canciones en favoritos.\n");
        } else {
            System.out.println("\n Tus canciones favoritas:");
            for (String cancion : cancionesFavoritas) {
                System.out.println(cancion);
            }
            System.out.println();
        }
    }

    public void menu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("===  GESTOR DE CANCIONES FAVORITAS ===");
            System.out.println("1. Agregar canción a favoritos");
            System.out.println("2. Eliminar canción de favoritos");
            System.out.println("3. Listar canciones favoritas");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.print("Ingrese el nombre de la canción: ");
                    String cancion = scanner.nextLine();
                    agregarCancion(cancion);
                }
                case 2 -> {
                    System.out.print("Ingrese el nombre de la canción a eliminar: ");
                    String cancion = scanner.nextLine();
                    eliminarCancion(cancion);
                }
                case 3 -> listarFavoritos();
                case 4 -> System.out.println(" Saliendo del gestor de favoritos...");
                default -> System.out.println(" Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 4);
    }

    public static void main(String[] args) {
        FavoritosMusicales favoritos = new FavoritosMusicales();
        favoritos.menu();
    }
}
