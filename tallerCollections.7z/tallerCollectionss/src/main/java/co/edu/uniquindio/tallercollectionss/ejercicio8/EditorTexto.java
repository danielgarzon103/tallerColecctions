package co.edu.uniquindio.tallercollectionss.ejercicio8;
import java.util.Vector;
import java.util.Scanner;

public class EditorTexto {
    private Vector<String> historial = new Vector<>();
    private String textoActual = "";

    // Agregar un nuevo cambio al historial
    public void agregarCambio(String nuevoTexto) {
        historial.add(textoActual); // Guardar estado anterior
        textoActual = nuevoTexto;
        System.out.println("Cambio guardado: " + textoActual + "\n");
    }

    // Deshacer el último cambio
    public void deshacer() {
        if (!historial.isEmpty()) {
            textoActual = historial.lastElement(); // Restaurar el último estado
            historial.remove(historial.size() - 1); // Eliminar el cambio deshecho
            System.out.println("Último cambio deshecho. Texto actual: " + textoActual + "\n");
        } else {
            System.out.println("No hay cambios para deshacer.\n");
        }
    }

    // Mostrar el historial de cambios
    public void mostrarHistorial() {
        if (historial.isEmpty()) {
            System.out.println("El historial está vacío.\n");
        } else {
            System.out.println("\nHistorial de cambios:");
            for (int i = 0; i < historial.size(); i++) {
                System.out.println((i + 1) + ". " + historial.get(i));
            }
            System.out.println();
        }
    }

    // Menú interactivo
    public void menu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("=== EDITOR DE TEXTO ===");
            System.out.println("1. Agregar cambio");
            System.out.println("2. Deshacer último cambio");
            System.out.println("3. Mostrar historial de cambios");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1 -> {
                    System.out.print("Ingrese el nuevo texto: ");
                    String nuevoTexto = scanner.nextLine();
                    agregarCambio(nuevoTexto);
                }
                case 2 -> deshacer();
                case 3 -> mostrarHistorial();
                case 4 -> System.out.println("Saliendo del editor...");
                default -> System.out.println("Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 4);
    }

    public static void main(String[] args) {
        EditorTexto editor = new EditorTexto();
        editor.menu();
    }
}
