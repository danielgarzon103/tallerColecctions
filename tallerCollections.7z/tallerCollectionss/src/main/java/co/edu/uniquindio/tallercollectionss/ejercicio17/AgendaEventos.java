package co.edu.uniquindio.tallercollectionss.ejercicio17;
import java.time.LocalDate;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class AgendaEventos {
    private TreeMap<LocalDate, String> eventos;

    public AgendaEventos() {
        this.eventos = new TreeMap<>();
    }

    public void agregarEvento(String nombre, LocalDate fecha) {
        eventos.put(fecha, nombre);
        System.out.println("Evento agregado: " + nombre + " - " + fecha);
    }

    public void mostrarEventos() {
        if (eventos.isEmpty()) {
            System.out.println("No hay eventos en la agenda.");
        } else {
            System.out.println("Lista de eventos:");
            for (Map.Entry<LocalDate, String> entry : eventos.entrySet()) {
                System.out.println(entry.getKey() + " - " + entry.getValue());
            }
        }
    }

    public void proximoEvento() {
        if (eventos.isEmpty()) {
            System.out.println("No hay eventos programados.");
        } else {
            Map.Entry<LocalDate, String> proximo = eventos.firstEntry();
            System.out.println("Próximo evento: " + proximo.getValue() + " - " + proximo.getKey());
        }
    }

    public void eliminarEvento(LocalDate fecha) {
        if (eventos.remove(fecha) != null) {
            System.out.println("Evento en " + fecha + " eliminado.");
        } else {
            System.out.println("No se encontró un evento en esa fecha.");
        }
    }

    public static void main(String[] args) {
        AgendaEventos agenda = new AgendaEventos();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nMenú de la Agenda de Eventos:");
            System.out.println("1. Agregar evento");
            System.out.println("2. Mostrar eventos");
            System.out.println("3. Consultar próximo evento");
            System.out.println("4. Eliminar evento");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Fecha (YYYY-MM-DD): ");
                    LocalDate fecha = LocalDate.parse(scanner.nextLine());
                    System.out.print("Nombre del evento: ");
                    String nombre = scanner.nextLine();
                    agenda.agregarEvento(nombre, fecha);
                    break;
                case 2:
                    agenda.mostrarEventos();
                    break;
                case 3:
                    agenda.proximoEvento();
                    break;
                case 4:
                    System.out.print("Fecha del evento a eliminar (YYYY-MM-DD): ");
                    LocalDate fechaEliminar = LocalDate.parse(scanner.nextLine());
                    agenda.eliminarEvento(fechaEliminar);
                    break;
                case 0:
                    System.out.println("Agenda cerrada.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}
