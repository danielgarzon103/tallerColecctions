package co.edu.uniquindio.tallercollectionss.ejercicio4;

import java.util.PriorityQueue;

public class Main {
    public static void main(String[] args) {
        PriorityQueue<Tarea> colaDeTareas = new PriorityQueue<>();

        colaDeTareas.add(new Tarea("Terminar informe", 2));
        colaDeTareas.add(new Tarea("Responder correos", 3));
        colaDeTareas.add(new Tarea("Reunión con equipo", 1));
        colaDeTareas.add(new Tarea("Revisar código", 4));

        System.out.println("Procesando tareas según su prioridad:");
        while (!colaDeTareas.isEmpty()) {
            System.out.println(colaDeTareas.poll());
        }
    }
}